public abstract class ItemBiblioteca {
    private final int codigo;
    private final String titulo;
    private boolean disponivel;

    public ItemBiblioteca(int codigo, String titulo) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.disponivel = true;
    }

    public int getCodigo() { return codigo; }
    public String getTitulo() { return titulo; }
    public boolean isDisponivel() { return disponivel; }

    // A disponibilidade muda como consequência de emprestar/devolver.
    void marcarEmprestado() { disponivel = false; }
    void marcarDevolvido() { disponivel = true; }

    public abstract int prazoEmDias();
    public abstract double multaPorDia();

    public double calcularMulta(int diasAtraso) {
        return Math.max(0, diasAtraso) * multaPorDia();
    }

    @Override
    public String toString() {
        return "Código: " + codigo + " | Título: " + titulo
                + " | Prazo: " + prazoEmDias() + " dias"
                + " | Multa/dia: R$ " + String.format("%.2f", multaPorDia())
                + " | Disponível: " + (disponivel ? "Sim" : "Não");
    }
}
