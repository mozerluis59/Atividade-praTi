public class Revista extends ItemBiblioteca {
    public Revista(int codigo, String titulo) {
        super(codigo, titulo);
    }

    @Override
    public int prazoEmDias() { return 7; }

    @Override
    public double multaPorDia() { return 1.00; }
}
