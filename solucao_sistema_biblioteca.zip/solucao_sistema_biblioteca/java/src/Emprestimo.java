public class Emprestimo {
    private final ItemBiblioteca item;
    private final Usuario usuario;
    private boolean devolvido;

    public Emprestimo(ItemBiblioteca item, Usuario usuario) {
        this.item = item;
        this.usuario = usuario;
        this.devolvido = false;
    }

    public ItemBiblioteca getItem() { return item; }
    public Usuario getUsuario() { return usuario; }
    public boolean isDevolvido() { return devolvido; }

    void marcarDevolvido() { devolvido = true; }
}
