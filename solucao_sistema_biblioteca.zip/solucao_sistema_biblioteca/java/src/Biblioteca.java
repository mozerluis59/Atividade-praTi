public class Biblioteca {
    private final ItemBiblioteca[] acervo;
    private final Emprestimo[] emprestimos;
    private int quantidadeItens;
    private int quantidadeEmprestimos;

    public Biblioteca(int capacidadeAcervo, int capacidadeEmprestimos) {
        acervo = new ItemBiblioteca[capacidadeAcervo];
        emprestimos = new Emprestimo[capacidadeEmprestimos];
    }

    public boolean cadastrarItem(ItemBiblioteca item) {
        if (item == null || quantidadeItens >= acervo.length) {
            System.out.println("Não foi possível cadastrar o item: acervo cheio ou item inválido.");
            return false;
        }
        acervo[quantidadeItens++] = item;
        return true;
    }

    public boolean emprestar(int codigoItem, Usuario usuario) {
        ItemBiblioteca item = buscarItem(codigoItem);

        if (item == null) {
            System.out.println("Empréstimo recusado: item não encontrado.");
            return false;
        }
        if (!item.isDisponivel()) {
            System.out.println("Empréstimo recusado: item indisponível.");
            return false;
        }
        if (usuario == null || !usuario.podeEmprestar()) {
            System.out.println("Empréstimo recusado: limite de itens do usuário atingido.");
            return false;
        }
        if (quantidadeEmprestimos >= emprestimos.length) {
            System.out.println("Empréstimo recusado: capacidade de registros atingida.");
            return false;
        }

        emprestimos[quantidadeEmprestimos++] = new Emprestimo(item, usuario);
        item.marcarEmprestado();
        usuario.registrarEmprestimo();
        System.out.println("Empréstimo realizado: " + item.getTitulo() + " para " + usuario.getNome() + ".");
        return true;
    }

    public boolean devolver(int codigoItem) {
        for (int i = 0; i < quantidadeEmprestimos; i++) {
            Emprestimo emprestimo = emprestimos[i];
            if (emprestimo.getItem().getCodigo() == codigoItem && !emprestimo.isDevolvido()) {
                emprestimo.marcarDevolvido();
                emprestimo.getItem().marcarDevolvido();
                emprestimo.getUsuario().registrarDevolucao();
                System.out.println("Devolução registrada: " + emprestimo.getItem().getTitulo() + ".");
                return true;
            }
        }
        System.out.println("Devolução não realizada: não há empréstimo em aberto para esse código.");
        return false;
    }

    public void listarAcervo() {
        System.out.println("\\n=== ACERVO DA BIBLIOTECA ===");
        for (ItemBiblioteca item : acervo) {
            if (item != null) {
                // Polimorfismo: cada item informa seu próprio prazo e sua própria multa.
                System.out.println(item);
            }
        }
    }

    private ItemBiblioteca buscarItem(int codigo) {
        for (int i = 0; i < quantidadeItens; i++) {
            if (acervo[i].getCodigo() == codigo) {
                return acervo[i];
            }
        }
        return null;
    }
}
