public class Main {
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca(10, 20);

        // Cadastro do acervo
        biblioteca.cadastrarItem(new Livro(1, "Java: Como Programar"));
        biblioteca.cadastrarItem(new Livro(2, "Use a Cabeça! Java"));
        biblioteca.cadastrarItem(new Livro(3, "Banco de Dados"));
        biblioteca.cadastrarItem(new Revista(4, "Revista de Tecnologia"));

        Aluno aluno = new Aluno("Ana Souza");
        Professor professor = new Professor("Carlos Lima");

        // Empréstimo bem-sucedido
        biblioteca.emprestar(1, aluno);

        // Preenche o limite do aluno (3 itens simultâneos)
        biblioteca.emprestar(2, aluno);
        biblioteca.emprestar(3, aluno);

        // Deve ser recusado: o aluno já está com 3 itens emprestados
        biblioteca.emprestar(4, aluno);

        // Demonstra que professor pode emprestar e que a devolução funciona
        biblioteca.emprestar(4, professor);
        biblioteca.devolver(4);

        biblioteca.listarAcervo();
    }
}
