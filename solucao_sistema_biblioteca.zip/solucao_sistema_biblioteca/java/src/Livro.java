public class Livro extends ItemBiblioteca {
    public Livro(int codigo, String titulo) {
        super(codigo, titulo);
    }

    @Override
    public int prazoEmDias() { return 14; }

    @Override
    public double multaPorDia() { return 0.50; }
}
