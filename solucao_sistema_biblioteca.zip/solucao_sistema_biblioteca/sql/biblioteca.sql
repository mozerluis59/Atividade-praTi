-- Exercício 2: modelagem do sistema de biblioteca (PostgreSQL)

CREATE TABLE item (
    id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo INTEGER NOT NULL UNIQUE,
    titulo VARCHAR(150) NOT NULL,
    tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('livro', 'revista')),
    autor VARCHAR(120),
    edicao VARCHAR(50),
    disponivel BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE usuario (
    id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('aluno', 'professor')),
    limite_itens INTEGER NOT NULL CHECK (limite_itens > 0)
);

CREATE TABLE emprestimo (
    id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    item_id INTEGER NOT NULL REFERENCES item(id),
    usuario_id INTEGER NOT NULL REFERENCES usuario(id),
    data_retirada DATE NOT NULL,
    data_devolucao_prevista DATE NOT NULL,
    data_devolucao DATE,
    valor_multa NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (valor_multa >= 0)
);

-- Exercício 2: dados de teste (4 itens, 2 usuários, 2 empréstimos)
INSERT INTO item (codigo, titulo, tipo, autor, edicao, disponivel) VALUES
(101, 'Java: Como Programar', 'livro', 'Paul Deitel', '10ª edição', FALSE),
(102, 'Banco de Dados', 'livro', 'Ramez Elmasri', '7ª edição', TRUE),
(103, 'Revista Tecnologia Hoje', 'revista', NULL, 'Edição 45', TRUE),
(104, 'Revista Ciência', 'revista', NULL, 'Edição 12', TRUE);

INSERT INTO usuario (nome, tipo, limite_itens) VALUES
('Ana Souza', 'aluno', 3),
('Carlos Lima', 'professor', 5);

-- Um empréstimo em aberto e outro já devolvido
INSERT INTO emprestimo
(item_id, usuario_id, data_retirada, data_devolucao_prevista, data_devolucao, valor_multa)
VALUES
(1, 1, CURRENT_DATE - 10, CURRENT_DATE + 4, NULL, 0.00),
(2, 2, CURRENT_DATE - 20, CURRENT_DATE - 6, CURRENT_DATE - 5, 0.50);

-- Exercício 3.1: listar o acervo com código, título, tipo e disponibilidade
SELECT codigo, titulo, tipo, disponivel
FROM item
ORDER BY codigo;

-- Exercício 3.2: empréstimos em aberto com usuário e título do item
SELECT u.nome AS usuario, i.titulo AS item, e.data_retirada, e.data_devolucao_prevista
FROM emprestimo e
JOIN usuario u ON u.id = e.usuario_id
JOIN item i ON i.id = e.item_id
WHERE e.data_devolucao IS NULL
ORDER BY e.data_retirada;

-- Exercício 3.3: total de multas acumuladas por usuário
SELECT u.nome AS usuario, COALESCE(SUM(e.valor_multa), 0.00) AS total_multas
FROM usuario u
LEFT JOIN emprestimo e ON e.usuario_id = u.id
GROUP BY u.id, u.nome
ORDER BY u.nome;

-- Exercício 3.4: itens que nunca foram emprestados
SELECT i.codigo, i.titulo, i.tipo
FROM item i
LEFT JOIN emprestimo e ON e.item_id = i.id
WHERE e.id IS NULL
ORDER BY i.codigo;
