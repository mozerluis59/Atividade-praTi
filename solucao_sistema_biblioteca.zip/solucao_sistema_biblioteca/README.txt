SOLUÇÃO — SISTEMA DE BIBLIOTECA
Java (POO) + PostgreSQL

CONTEÚDO
- java/src: classes Java separadas por arquivo.
- sql/biblioteca.sql: criação das tabelas, dados de teste e quatro consultas SQL.

EXERCÍCIO 1 — COMO EXECUTAR
1. Instale um JDK (Java 17 ou superior recomendado).
2. Abra um terminal dentro da pasta java/src.
3. Compile:
   javac *.java
4. Execute:
   java Main

O programa cadastra livros e revistas, faz empréstimos, demonstra a recusa quando o aluno atinge o limite de 3 itens, registra uma devolução e lista o acervo.

EXERCÍCIOS 2 E 3 — COMO EXECUTAR
1. Abra o pgAdmin ou outro cliente PostgreSQL.
2. Conecte-se ao banco de dados desejado.
3. Abra e execute sql/biblioteca.sql.
   O script cria as tabelas, insere os dados de teste e executa as quatro consultas.

OBSERVAÇÕES
- O exercício Java usa arrays de tamanho fixo.
- ItemBiblioteca e Usuario são classes abstratas.
- Livro/Revista e Aluno/Professor implementam os métodos abstratos.
- listarAcervo percorre ItemBiblioteca[] sem verificar o tipo de cada item.
- No SQL, emprestimo é criado depois de item e usuario por depender das chaves estrangeiras.
- O valor de multa inserido no empréstimo já devolvido é apenas um dado de teste.
